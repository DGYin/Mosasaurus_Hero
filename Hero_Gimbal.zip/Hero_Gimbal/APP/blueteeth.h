#ifndef __BLUETEETH__H
#define __BLUETEETH__H


void blueteeth_trans(void);



#endif



